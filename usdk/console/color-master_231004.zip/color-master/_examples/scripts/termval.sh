#!/usr/bin/env sh
env | grep -i term
